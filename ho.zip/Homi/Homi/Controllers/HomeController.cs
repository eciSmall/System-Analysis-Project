﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Homi.Models;
using MySql.Data;

namespace Homi.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult mainPage()

        {
            return View("view2");
            //Response.AddHeader("Content-Disposition", new System.Net.Mime.ContentDisposition { Inline = true, FileName = "login1.html" }.ToString());
            //var path = @"C:\Users\Muhammad Ehsan\Documents\Visual Studio 2015\Projects\Homi\Homi\Views\Home\index3.html";
            //return new FilePathResult(path, "text/html");
        }
        public void string1()
        {
            WebAdmin wb = new WebAdmin();
            ViewData["h"] = wb;
            wb.InsertToDb("hasan", "123");
        }
    }
}