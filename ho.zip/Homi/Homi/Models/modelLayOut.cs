﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Homi.Models
{
    public class modelLayOut
    {
        Models m = new Models();
        public void getAdminUsername(string username)
        {
            m.setAdminUser(username);
            m.setAdminPass(username);
        }
        public void getAdminPassword(string password)
        {
            m.setAdminPass(password);
        }
    }
}