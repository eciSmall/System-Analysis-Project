﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data;
using MySql.Data.MySqlClient;

namespace Homi.Models
{
    public class WebAdmin
    {
        private agency ag = new agency();
        public void InsertToDb(string username, string password)
        {
            MySqlConnection objConnection = new MySqlConnection("SERVER =127.0.0.1; " + "UserID=root;" + "password=ehsan;" + "DATABASE = homi; ");
            try
            {
                objConnection.Open();
                MySqlCommand objCommand = new MySqlCommand();
                objCommand.Connection = objConnection;
                objCommand.CommandText = "INSERT INTO admin (username, password) VALUES ('" + username + "', '" + password + "')";
                objCommand.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            objConnection.Close();
        }

        public void DeleteFromDb(string tableName)
        {
            MySqlConnection objConnection = new MySqlConnection("SERVER =127.0.0.1; " + "UserID=root;" + "password=ehsan;" + "DATABASE = homi; ");
            try
            {

                objConnection.Open();
                MySqlCommand objCommand = new MySqlCommand();
                objCommand.Connection = objConnection;
                objCommand.CommandText = "DELETE FROM admin";
                objCommand.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            objConnection.Close();
        }

        public void UpdateDb(string condition, string ask)
        {
            MySqlConnection objConnection = new MySqlConnection("SERVER =127.0.0.1; " + "UserID=root;" + "password=ehsan;" + "DATABASE = homi; ");
            try
            {

                objConnection.Open();
                MySqlCommand objCommand = new MySqlCommand();
                objCommand.Connection = objConnection;
                objCommand.CommandText = "UPDATE admin SET password = '" + ask + "'WHERE username = '" + condition + "'";
                objCommand.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            objConnection.Close();
        }

        public void createAccountForAgency(string name, string address, int phoneNumber, string username, string password)
        {
            ag.InsertToDb(name, address, phoneNumber, username, password);    
        }

        public void updateAccountForAgency(string condition, string ask, string whichOne)
        {
            ag.UpdateDb(condition, ask, whichOne);
        }
    }
}
